import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Modal,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,Platform,
  View,Button,
} from "react-native";
import axios from "axios";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { Mic, Plus } from "lucide-react-native";
import { Audio } from "expo-av";
import { router } from "expo-router";
import { LinearGradient } from "expo-linear-gradient";
import AsyncStorage from "@react-native-async-storage/async-storage";
import * as FileSystem from 'expo-file-system';
import { Asset } from 'expo-asset';
import { getMicrophonePermission } from "@/utils/permissionsUtils";
import fetchCityWeatherInfo from "@/utils/getWeatherByCord";
import fetchWeatherByCityKey from "@/utils/getWeatherByCityKey";
import { ACCUWEATHER_API_KEY } from "@/api";
import { prompt_assistant } from "@/utils/prompt";
import Sound from 'react-native-sound';
import { Buffer } from 'buffer';

import SoundPlayer from 'react-native-sound-player'
///

// Types
interface WeatherForecast {
  day: string;
  high: number;
  low: number;
}
interface WeatherInfo {
  cityName: string;
  countryName: string;
  temperature: number;
  weatherText: string;
}
// Recording options
interface RecordingOptions {
  android: {
    extension: string;
    outPutFormat: number;
    androidEncoder: number;
    sampleRate: number;
    numberOfChannels: number;
    bitRate: number;
  };
  ios: {
    extension: string;
    audioQuality: number;
    sampleRate: number;
    numberOfChannels: number;
    bitRate: number;
    linearPCMBitDepth: number;
    linearPCMIsBigEndian: boolean;
    linearPCMIsFloat: boolean;
  };
}
const FLASK_SERVER_URL = "https://055e-196-119-60-6.ngrok-free.app/transcribe";
const WeatherApp = () => {
  const [audioPath, setAudioPath] = useState('output.mp3'); // Path to the audio file
  const [sound, setSound] = useState(null);
  // State
  const [firstColor, setFirstColor] = useState<string>("#456bee");
  const [secondColor, setSecondColor] = useState<string>("#f0f8ff");
  const [modalVisible, setModalVisible] = useState(false);
  const [weatherInfo, setWeatherInfo] = useState<WeatherInfo | null>(null);
  const [forecast, setForecast] = useState<WeatherForecast[]>([]);
  const [recording, setRecording] = useState<Audio.Recording>();
  const [isRecording, setIsRecording] = useState(false);
  const [transcript, setTranscript] = useState<string>("");
    const [assistext, setAssistext] = useState<string>("");
    const [assisreply, setAssisreply] = useState(false);
    const [assisloading, setAssisloading] = useState(false);

// recording options
const recordingOptions: RecordingOptions = {
  android: {
    extension: ".mp3",
    outPutFormat: Audio.AndroidOutputFormat.MPEG_4,
    androidEncoder: Audio.AndroidAudioEncoder.AAC,
    sampleRate: 48000, // Higher sample rate for better audio quality
    numberOfChannels: 2, // Stereo recording
    bitRate: 192000, 
  },
  ios: {
    extension: ".mp3",
    audioQuality: Audio.IOSAudioQuality.HIGH,
    sampleRate: 44100,
    numberOfChannels: 2,
    bitRate: 128000,
    linearPCMBitDepth: 16,
    linearPCMIsBigEndian: false,
    linearPCMIsFloat: false,
  },
};
////
  useEffect(() => {
    fetchWeatherData();
  }, []);

  const fetchWeatherData = async () => {
    try {
      const cityKey = await AsyncStorage.getItem("city-key");

      if (cityKey) {
        console.log("Fetching weather data by city key...");
        const weatherData = await fetchWeatherByCityKey(cityKey, ACCUWEATHER_API_KEY);
        
        if (weatherData) {
          setWeatherInfo(weatherData);
          setDefaultForecast();
        }
      } else {
        console.log("Fetching weather data by location...");
        const location = await AsyncStorage.getItem("userLocation");
        const parsedLocation = JSON.parse(location || "");

        if (parsedLocation) {
          const { latitude, longitude } = parsedLocation;
          if (latitude && longitude) {
            const weatherData = await fetchCityWeatherInfo(
              latitude,
              longitude,
              ACCUWEATHER_API_KEY
            );

            if (weatherData) {
              setWeatherInfo(weatherData);
              setDefaultForecast();
            }
          }
        }
      }
    } catch (error) {
      console.error("Error fetching weather data:", error);
      Alert.alert("Error", "Failed to fetch weather data.");
    }
  };

  const setDefaultForecast = () => {
    setForecast([
      { day: "Monday", high: 24, low: 12 },
      { day: "Tuesday", high: 22, low: 10 },
      { day: "Wednesday", high: 26, low: 15 },
    ]);
  };

  const startRecording = async () => {
    try {
      const hasPermission = await getMicrophonePermission();
      if (!hasPermission) {
        Alert.alert("Permission Required", "Microphone permission is required to record audio.");
        return;
      }

      await Audio.setAudioModeAsync({
        allowsRecordingIOS: true,
        playsInSilentModeIOS: true,
      });

     // const newRecording = new Audio.Recording();
      //await newRecording.prepareToRecordAsync(recordingOptions);
      //await newRecording.startAsync();
      const { recording } = await Audio.Recording.createAsync(recordingOptions);
      setIsRecording(true);
      setRecording(recording);
      //setRecording(newRecording);
     // setIsRecording(true);
      
      console.log("Recording started successfully");
    } catch (error) {
      console.error("Failed to start recording:", error);
      Alert.alert("Error", "Failed to start recording. Please try again.");
    }
  };

  const stopRecording = async () => {
    try {
      if (!recording || !isRecording) {
        console.log("No active recording to stop");
        return;
      }

      setIsRecording(false);
      console.log("Stopping recording...");

      await recording.stopAndUnloadAsync();

      await Audio.setAudioModeAsync({ allowsRecordingIOS: false });

      const uri = recording.getURI();
      //setRecording(null);

      if (!uri) {
        throw new Error("Recording URI is undefined");
      }

      await uploadRecording(uri);
    } catch (error) {
      console.error("Error stopping recording:", error);
      Alert.alert("Error", "Failed to process recording. Please try again.");
    }
  };
//// start and stopped done

  // const saveRecordingToAssets = async (uri: string): Promise<string> => {
  //   try {
  //     // Create assets directory if it doesn't exist
  //     const assetsDir = `${FileSystem.documentDirectory}assets/`;
  //     const assetsDirInfo = await FileSystem.getInfoAsync(assetsDir);
      
  //     if (!assetsDirInfo.exists) {
  //       await FileSystem.makeDirectoryAsync(assetsDir, { intermediates: true });
  //     }

  //     // Generate unique filename
  //     const filename = `recording_${Date.now()}.wav`;
  //     const newUri = `${assetsDir}${filename}`;

  //     // Copy recording to assets directory
  //     await FileSystem.copyAsync({
  //       from: uri,
  //       to: newUri
  //     });

  //     console.log('Recording saved to assets:', newUri);
  //     return newUri;
  //   } catch (error) {
  //     console.error('Error saving recording to assets:', error);
  //     throw error;
  //   }
  // };
  // const verifyFileCreation = async (uri) => {
  //   try {
  //     const fileInfo = await FileSystem.getInfoAsync(uri);
  //     if (fileInfo.exists) {
  //       console.log("File exists at:", uri);
  //     } else {
  //       console.log("File does not exist.");
  //     }
  //   } catch (error) {
  //     console.error("Error verifying file creation:", error);
  //   }
  // };
  
  // const loadAssetForUpload = async (uri: string) => {
  //   try {
  //     const asset = await Asset.loadAsync(uri);
  //     return asset[0];
  //   } catch (error) {
  //     console.error('Error loading asset:', error);
  //     throw error;
  //   }
  // };


  const playAudio = () => {
    console.log("Playing audio...");
    if (!audioPath) {
      console.warn('Audio path not set');
      return;
    }
  };
  const stopAudio = () => {
    if (!audioPath) {
      console.warn('Audio not stopped');
      return;
    }
  };
  
  const uploadRecording = async (uri: string) => {
    try {
      console.log("Starting audio upload with URI:", uri);

      // Save recording to assets folder
      //const assetUri = await saveRecordingToAssets(uri);
      
      // Load the saved recording as an asset
      //const asset = await loadAssetForUpload(assetUri);
      
      const formData = new FormData();
      formData.append("file", {
        uri: Platform.OS === 'ios' ? uri.replace('file://', '') : uri,
        type: "audio/mp3",
        name: "recording.mp3"
      } as any);
         
      const response = await axios.post(
        "https://055e-196-119-60-6.ngrok-free.app/transcribe", 
        formData, 
        {
          headers: {
            "Content-Type": "multipart/form-data",
            "Accept": "application/json",
          },
        }
      );
      
      console.log("Transcription:", response.data);
      const transcript = response.data.transcriptions[0]?.transcript;
     const ass_text= sendToGemini(prompt_assistant,transcript);

      console.log("Transcription:", transcript);
      console.log("this is assisant reply",assistext);
/// read the assiatant reply
try{
  const response_audio = await axios.post(
    "https://api.play.ht/api/v2/tts/stream",
    {
      text: assistext,
      voice_engine: "PlayDialog",
      voice: "s3://voice-cloning-zero-shot/d9ff78ba-d016-47f6-b0ef-dd630f59414e/female-cs/manifest.json",
      output_format: "mp3",
    },
    {
      headers: {
        "X-USER-ID": "c4tWRiKDPdXnmkX8A4tBaMukT7k1",
        AUTHORIZATION: "6b91dd8a331249ff9623014eb8533293",
        accept: "audio/mpeg",
        "content-type": "application/json",
      },
      responseType: "arraybuffer", // Ensures response is binary data
    }
  ); 
  console.log("audio of assis",);
  const base64Audio = `data:audio/mp3;base64,${Buffer.from(response_audio.data).toString('base64')}`;


  // Load and play the audio using expo-av
  const soundObject = new Audio.Sound();
  await soundObject.loadAsync({ uri: base64Audio });
  await soundObject.playAsync();
  // working but slow due to file saving --------------------------------
  // const audioFilePath = `${FileSystem.cacheDirectory}assistant-reply.mp3`;
  //   await FileSystem.writeAsStringAsync(
  //     audioFilePath,
  //     Buffer.from(response_audio.data).toString('base64'),
  //     { encoding: FileSystem.EncodingType.Base64 }
  //   );

  //   console.log("Audio file saved to:", audioFilePath);

  //   // Load and play the audio using expo-av
  //   const soundObject = new Audio.Sound();
  //   await soundObject.loadAsync({ uri: audioFilePath });
  //   await soundObject.playAsync();

  // ----------------------------------------------------------------//
}catch(error){
  console.log("reading assis text failed",error);
}
        //setTranscript(data.transcript);
      return response.data.transcriptions[0]?.transcript;
    } catch (error) {
      console.error("Error uploading recording:", error);
      Alert.alert("Error", "Failed to upload recording. Please try again.");
    }
  };
  async function sendToGemini(prompt: string, userText: string): Promise<string> {
    const GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1/models/gemini-pro:generateContent';
    const GEMINI_API_KEY = 'AIzaSyCcWWbB0FzPrZqeehhZPfzITbBLWYXcycY'; // Replace with your actual API key.
  
    const requestPayload = {
      contents: [
        {
          parts: [
            { text: `${prompt} ${userText}` },
          ],
        },
      ],
    };
  
    try {
      const response = await axios.post<GeminiResponse>(
        `${GEMINI_API_URL}?key=${GEMINI_API_KEY}`,
        requestPayload,
        {
          headers: {
            'Content-Type': 'application/json',
          },
        }
      );
      setAssisloading(true);
      if (response.data.candidates?.[0]?.content?.parts?.[0]?.text) {
        setAssisreply(true);
        setAssisloading(false);
       // console.log("inside gem",response.data.candidates?.[0]?.content.parts[0].text);
       setAssistext(response.data.candidates?.[0]?.content.parts[0].text);
        return response.data.candidates?.[0]?.content.parts[0].text;
      } else {
        throw new Error('No content generated by Gemini API');
      }
    } catch (error) {
      if (axios.isAxiosError(error) && error.response) {
        console.error('Gemini API Error:', error.response.data);
        throw new Error(`Gemini API Error: ${error.response.statusText}`);
      }
      throw new Error(`Request failed: ${error.message}`);
    }
  }
  const handleModalClose = () => {
    if (isRecording) {
      stopRecording();
    }
    setModalVisible(false);
  };
///

// const playAudio = (audioData: ArrayBuffer) => {
//   // Convert binary data to a Blob and create a local file path
//   const blob = new Blob([audioData], { type: 'audio/mpeg' });
//   const url = URL.createObjectURL(blob);

//   const sound = new Sound(url, Sound.MAIN_BUNDLE, (error) => {
//     if (error) {
//       console.log('Failed to load the sound', error);
//       return;
//     }
//     // Play the sound
//     sound.play((success) => {
//       if (success) {
//         console.log('Successfully finished playing');
//       } else {
//         console.log('Playback failed due to audio decoding errors');
//       }
//     });
//   });
// };

//////
  return (
    <SafeAreaProvider>
      <LinearGradient colors={[firstColor, secondColor]} style={styles.container}>
        <ScrollView
          contentContainerStyle={{ paddingBottom: 20 }}
          showsVerticalScrollIndicator={false}
        >
          <TouchableOpacity
            style={styles.plusButton}
            onPress={() => router.push("/(root)/add-city")}
          >
            <Plus size={44} color="white" />
          </TouchableOpacity>

          <View style={styles.weatherContainer}>
            {weatherInfo ? (
              <>
                <Text style={styles.cityText}>{weatherInfo.cityName}</Text>
                <Text style={styles.countryText}>{weatherInfo.countryName}</Text>
                <Text style={styles.tempText}>{`${weatherInfo.temperature}°C`}</Text>
                <Text style={styles.weatherText}>{weatherInfo.weatherText}</Text>
              </>
            ) : (
              <ActivityIndicator size="large" color="#fff" />
            )}
          </View>

          <View>
            {forecast.map((item, index) => (
              <View key={index} style={styles.forecastRow}>
                <Text style={styles.forecastText}>{item.day}</Text>
                <Text style={styles.forecastText}>{`${item.high}°/${item.low}°`}</Text>
              </View>
            ))}
          </View>
        </ScrollView>
        <View style={{ padding: 20 }}>
      <Text>Audio Player</Text>
      <Button title="Play Audio" onPress={playAudio} />
      <Button title="Stop Audio" onPress={stopAudio} />
    </View>
        <TouchableOpacity
          style={styles.micButton}
          onPress={() => setModalVisible(true)}
        >
          <Mic size={28} color="white" />
        </TouchableOpacity>

        <Modal
          animationType="slide"
          transparent
          visible={modalVisible}
          onRequestClose={handleModalClose}
        >
          <View style={styles.modalOverlay}>
            <View style={styles.modalContent}>
              <Mic size={48} color="#007AFF" />
              {isRecording ? (
                <Text style={styles.listeningText}>I'm listening test...</Text>
              ) : (
                <Text style={styles.modalDescription}>
                  Tap the button and start talking!
                </Text>
              )}
              
              {isRecording && (
                <ActivityIndicator
                  size="large"
                  color="#007AFF"
                  style={{ marginTop: 20 }}
                />
              )}

              {transcript && (
                <Text style={styles.transcriptText}>
                  Transcript: {transcript}
                </Text>
              )}

              <TouchableOpacity
                style={styles.recordButton}
                onPress={isRecording ? stopRecording : startRecording}
              >
                <Text style={styles.recordButtonText}>
                  {isRecording ? "Stop Recording" : "Start Recording"}
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.closeButton}
                onPress={handleModalClose}
              >
                <Text style={styles.closeButtonText}>Close</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      </LinearGradient>
    </SafeAreaProvider>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  weatherContainer: {
    alignItems: "center",
    paddingVertical: 36,
  },
  cityText: {
    fontSize: 36,
    fontWeight: "bold",
    color: "#fff",
  },
  countryText: {
    fontSize: 24,
    color: "#fff",
  },
  tempText: {
    fontSize: 48,
    fontWeight: "bold",
    color: "#fff",
  },
  weatherText: {
    fontSize: 20,
    color: "#fff",
    marginVertical: 10,
  },
  plusButton: {
    position: "absolute",
    top: 30,
    right: 20,
  },
  forecastRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    padding: 10,
    borderBottomWidth: 1,
    borderColor: "#ddd",
  },
  forecastText: {
    fontSize: 20,
    color: "#fff",
  },
  micButton: {
    position: "absolute",
    bottom: 30,
    right: 20,
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: "#007AFF",
    justifyContent: "center",
    alignItems: "center",
    elevation: 5,
    shadowColor: "#000",
    shadowOpacity: 0.2,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 4,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.5)",
    justifyContent: "center",
    alignItems: "center",
  },
  modalContent: {
    width: "90%",
    backgroundColor: "white",
    borderRadius: 10,
    padding: 20,
    alignItems: "center",
  },
  listeningText: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#007AFF",
    marginTop: 10,
  },
  modalDescription: {
    fontSize: 16,
    textAlign: "center",
    marginVertical: 20,
  },
  transcriptText: {
    fontSize: 16,
    textAlign: "center",
    marginVertical: 10,
    color: "#333",
  },
  closeButton: {
    backgroundColor: "#f0f0f0",
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    marginTop: 10,
  },
  closeButtonText: {
    color: "#007AFF",
    fontSize: 16,
  },
  recordButton: {
    backgroundColor: "#007AFF",
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    marginTop: 20,
  },
  recordButtonText: {
    color: "white",
    fontSize: 16,
  },
});

export default WeatherApp;